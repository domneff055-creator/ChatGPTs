# MyAI — iPhone Safari web app

This project includes a mobile-friendly ChatGPT-style UI and a server-side API route.

## Important
The ZIP is the app source, not a deployed website. For real AI responses, deploy it to a serverless host such as Vercel and configure `OPENAI_API_KEY` in the host's server environment settings. Never place the real key in `public/` files or in frontend JavaScript. API usage may incur separate charges.

## Files
- `public/index.html`: iPhone-friendly chat UI
- `api/chat.js`: secure server-side OpenAI Responses API call
- `public/manifest.json` and `public/icon.svg`: basic web-app metadata and icon
- `vercel.json`: serverless function configuration

The browser sends messages only to `/api/chat`; the API key stays on the server. Add authentication and rate limiting before sharing this app publicly, to prevent other people from consuming your API quota.

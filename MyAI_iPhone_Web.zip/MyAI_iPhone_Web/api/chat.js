import OpenAI from "openai";

const MAX_MESSAGES = 20;
const MAX_MESSAGE_CHARS = 6000;

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed." });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({
      error: "The app owner needs to configure the API key on the server."
    });
  }

  try {
    const messages = req.body?.messages;

    if (!Array.isArray(messages) || messages.length === 0 ||
        messages.length > MAX_MESSAGES) {
      return res.status(400).json({ error: "Please send a shorter conversation." });
    }

    const safeMessages = [];
    for (const message of messages) {
      if (!message || !["user", "assistant"].includes(message.role) ||
          typeof message.content !== "string" ||
          message.content.length > MAX_MESSAGE_CHARS) {
        return res.status(400).json({ error: "A message is invalid or too long." });
      }
      safeMessages.push({ role: message.role, content: message.content });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions:
        "You are MyAI, a helpful and friendly AI assistant. " +
        "Explain clearly and adapt to the user's level. Be safe and respectful.",
      input: safeMessages,
      max_output_tokens: 1200
    });

    return res.status(200).json({
      answer: response.output_text || "I couldn't generate a reply."
    });
  } catch (error) {
    console.error("MyAI API error:", error?.status || error?.name || "unknown");
    return res.status(500).json({
      error: "MyAI couldn't answer just now. Please try again."
    });
  }
}
